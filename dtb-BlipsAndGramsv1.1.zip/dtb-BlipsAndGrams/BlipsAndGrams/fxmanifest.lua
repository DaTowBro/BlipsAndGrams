fx_version 'adamant'
game 'gta5'
lua54 'yes'


escrow_ignore {
	'config.lua',

}

files {
'__resource.lua',
'LISCENSE.txt',
'README.txt',
'blipsandgrams.lua',
}