--[[
---------------------------------------BlipsAndGrams--------------------------------------------------------------------------
---------------------------------------by:DaTowBro#6980-----------------------------------------------------------------------
PATREON:https://www.patreon.com/DaTowBro6980   DISCORD:https://discord.gg/x6uExfUzHG     PAYPAL:https://www.paypal.me/paperrp
-------------------------------------------------------------------------------------------------------------------
	
	Just put in the coordinates you get when standing on the ground, it's above the ground then
	By default, you only see the hologram when you are within 10m of it, to change that, edit the 10.0 infront of the "then"
	The Default holograms are at the Observatory.

---------------------------------------DESCRIPTIONL---------------------------------------------------------------------
---------------------------------------HOW TO USE-----------------------------------------------------------------------
	
	If you want to add a line to the hologram, just make a new Draw3DText line with the same coordinates, and edit the vertical offset.
	
	Formatting:
			Draw3DText( x, y, z  vertical offset, "text", font, text size, text size)
			
			
	To add a new hologram, copy paste this example under the existing ones, and put coordinates and text into it.
	
		if GetDistanceBetweenCoords( X, Y, Z, GetEntityCoords(GetPlayerPed(-1))) < 10.0 then
			Draw3DText( X, Y, Z,  -1.400, "TEXT", 4, 0.1, 0.1)
			Draw3DText( X, Y, Z,  -1.600, "TEXT", 4, 0.1, 0.1)
			Draw3DText( X, Y, Z,  -1.800, "TEXT", 4, 0.1, 0.1)		
		end


]]--

--------------------------------------CONTROLER STARTS-------------------------------------------------------------------
---------------------------------------DO NOT EDIT-----------------------------------------------------------------------

Citizen.CreateThread(function()
    Holograms()
end)

function Holograms()
		while true do
			Citizen.Wait(0)	
---------------------------------------CONTROLLER ENDS-------------------------------------------------------------------
---------------------------------------DO NOT EDIT-----------------------------------------------------------------------


----------------------------------------HOLO TEXT CONFIG-----------------------------------------------------------------
------------------------------EDIT HERE ONLY -- SEE EXAMPLE ABOUVE-------------------------------------------------------

				-- Hologram No. 1 (MRPD Clock In/Out)
		if GetDistanceBetweenCoords( 441.31, -982.01, 30.69, GetEntityCoords(GetPlayerPed(-1))) < 10.0 then --This controls when holotext appears in relation to how close you are
			Draw3DText( 441.31, -982.01, 30.69  -1.400, "TEXT", 7, 0.1, 0.1) -- Simple Draw Text. Add your coordinates (x,y,z) 
			Draw3DText( 441.31, -982.01, 30.69  -1.600, "Here", 7, 0.1, 0.1)	
		end		
				--Hologram No. 2 (Forklift Job (Get Forklift))
		if GetDistanceBetweenCoords( 1201.49, -3287.56, 5.5, GetEntityCoords(GetPlayerPed(-1))) < 10.0 then --vector3(1201.37, -3288.2, 5.5)
			Draw3DText( 1201.49, -3287.56, 5.5  -1.400, "Get", 7, 0.1, 0.1)
			Draw3DText( 1201.49, -3287.56, 5.5  -1.600, "Forklift", 7, 0.1, 0.1)	
		end	
              --Hologram No. 3 (Forklift Job (Clock In/out))
		if GetDistanceBetweenCoords( 1205.62, -3259.58, 5.5, GetEntityCoords(GetPlayerPed(-1))) < 10.0 then --vector3(1201.37, -3288.2, 5.5)
			Draw3DText( 1205.62, -3259.58, 5.5  -1.400, "Clock", 7, 0.1, 0.1)
			Draw3DText( 1205.62, -3259.58, 5.5  -1.600, "In/Out", 7, 0.1, 0.1)	
		end	
				--Hologram No. 4 (Trucker Job (Get Truck))
		if GetDistanceBetweenCoords( 141.2, -3204.27, 5.86, GetEntityCoords(GetPlayerPed(-1))) < 10.0 then --vector3(1201.37, -3288.2, 5.5)
			Draw3DText( 141.2, -3204.27, 5.86  -1.400, "Get", 7, 0.1, 0.1)
			Draw3DText( 141.2, -3204.27, 5.86  -1.600, "Truck", 7, 0.1, 0.1)	
		end
			  --Hologram No. 5 (Taxi Job (Get Taxi))
		if GetDistanceBetweenCoords( 909.49, -177.24, 74.22, GetEntityCoords(GetPlayerPed(-1))) < 10.0 then --vector3(1201.37, -3288.2, 5.5)
			Draw3DText( 909.49, -177.24, 74.22  -1.400, "Get", 7, 0.1, 0.1)
			Draw3DText( 909.49, -177.24, 74.22  -1.600, "Taxi", 7, 0.1, 0.1)	
		end	
		      --Hologram No. 6 (Tow Job (Get Truck))
		if GetDistanceBetweenCoords( 489.67, -1331.82, 29.34, GetEntityCoords(GetPlayerPed(-1))) < 10.0 then --vector3(1201.37, -3288.2, 5.5)
			Draw3DText( 489.67, -1331.82, 29.34  -1.400, "Get", 7, 0.1, 0.1)
			Draw3DText( 489.67, -1331.82, 29.34  -1.600, "Truck", 7, 0.1, 0.1)	
		end	
			  --Hologram No. 7 (Trash Job (Get Truck))
		if GetDistanceBetweenCoords( -313.85, -1522.82, 27.56, GetEntityCoords(GetPlayerPed(-1))) < 10.0 then --vector3(1201.37, -3288.2, 5.5)
			Draw3DText( -313.85, -1522.82, 27.56  -1.400, "Get", 7, 0.1, 0.1)
			Draw3DText( -313.85, -1522.82, 27.56  -1.600, "Truck", 7, 0.1, 0.1)	
		end	
			  --Hologram No. 8 (Bus Job (Get Bus))
		if GetDistanceBetweenCoords( 451.65, -622.09, 28.63, GetEntityCoords(GetPlayerPed(-1))) < 10.0 then --vector3(1201.37, -3288.2, 5.5)
			Draw3DText( 451.65, -622.09, 28.63  -1.400, "Get", 7, 0.1, 0.1)
			Draw3DText( 451.65, -622.09, 28.63  -1.600, "Changed", 7, 0.1, 0.1)	
		end	
			  --Hologram No. 8 (Bus Job (Get Bus))
		if GetDistanceBetweenCoords( 460.79, -618.73, 28.5, GetEntityCoords(GetPlayerPed(-1))) < 10.0 then --vector3(1201.37, -3288.2, 5.5)
			Draw3DText( 460.79, -618.73, 28.5  -1.400, "Get", 7, 0.1, 0.1)
			Draw3DText( 460.79, -618.73, 28.5  -1.600, "Bus", 7, 0.1, 0.1)	
		end	
			  --Hologram No. 9 (Bus Job (Inspect Bus))
		if GetDistanceBetweenCoords( 465.4, -583.28, 28.5, GetEntityCoords(GetPlayerPed(-1))) < 10.0 then --vector3(1201.37, -3288.2, 5.5)
			Draw3DText( 465.4, -583.28, 28.5  -1.400, "Inspect", 7, 0.1, 0.1)
			Draw3DText( 465.4, -583.28, 28.5  -1.600, "Bus", 7, 0.1, 0.1)	
		end	
			  --Hologram No. 10 (Bus Job (Talk To))
		if GetDistanceBetweenCoords( 457.02, -550.34, 28.5, GetEntityCoords(GetPlayerPed(-1))) < 10.0 then --vector3(1201.37, -3288.2, 5.5)
			Draw3DText( 457.02, -550.34, 28.5  -1.400, "Talk", 7, 0.1, 0.1)
			Draw3DText( 457.02, -550.34, 28.5  -1.600, "To", 7, 0.1, 0.1)	
		end
			  --Hologram No. 11 (Bus Job (Get In))
		if GetDistanceBetweenCoords( 457.54, -558.27, 28.5, GetEntityCoords(GetPlayerPed(-1))) < 10.0 then --vector3(1201.37, -3288.2, 5.5)
			Draw3DText( 457.54, -558.27, 28.5  -1.400, "Get", 7, 0.1, 0.1)
			Draw3DText( 457.54, -558.27, 28.5  -1.600, "In", 7, 0.1, 0.1)	
		end
			  --Hologram No. 12 (Bus Job (End Job)) vector3(444.56, -590.19, 28.5)
		if GetDistanceBetweenCoords( 444.56, -590.19, 28.5, GetEntityCoords(GetPlayerPed(-1))) < 10.0 then --vector3(1201.37, -3288.2, 5.5)
			Draw3DText( 444.56, -590.19, 28.5  -1.400, "End", 7, 0.1, 0.1)
			Draw3DText( 444.56, -590.19, 28.5  -1.600, "Shift", 7, 0.1, 0.1)	
		end
			  --Hologram No. 13 (Bus Job (PickRoute)) vector3(470.09, -611.25, 28.5)
		if GetDistanceBetweenCoords( 470.09, -611.25, 28.5, GetEntityCoords(GetPlayerPed(-1))) < 10.0 then --vector3(1201.37, -3288.2, 5.5)
			Draw3DText( 470.09, -611.25, 28.5  -1.400, "Pick", 7, 0.1, 0.1)
			Draw3DText( 470.09, -611.25, 28.5  -1.600, "Route", 7, 0.1, 0.1)	
		end
	    	 --Hologram No. 14 (HotDog (Get Job)) vector3(39.29, -1004.91, 29.48)
	    if GetDistanceBetweenCoords( 39.29, -1004.91, 29.48, GetEntityCoords(GetPlayerPed(-1))) < 10.0 then --vector3(1201.37, -3288.2, 5.5)
		   Draw3DText( 39.29, -1004.91, 29.48  -1.400, "Get", 7, 0.1, 0.1)
		   Draw3DText( 39.29, -1004.91, 29.48  -1.600, "Job", 7, 0.1, 0.1)	
	    end
	 		 --Hologram No. 15 (Oil Well (Clock In/Out)) vector3(39.29, -1004.91, 29.48)
	 	if GetDistanceBetweenCoords( 1704.14, -1634.85, 112.51, GetEntityCoords(GetPlayerPed(-1))) < 10.0 then --vector3(1704.14, -1634.85, 112.51)
			Draw3DText( 1704.14, -1634.85, 112.51  -1.400, "Clock", 7, 0.1, 0.1)
			Draw3DText( 1704.14, -1634.85, 112.51  -1.600, "In/Out", 7, 0.1, 0.1)	
	 	end
			  --Hologram No. 16 (Taco (Talk To)) vector3(418.02, -1921.48, 25.18)
	    if GetDistanceBetweenCoords( 418.02, -1921.48, 25.18, GetEntityCoords(GetPlayerPed(-1))) < 10.0 then --vector3(1704.14, -1634.85, 112.51)
			Draw3DText( 418.02, -1921.48, 25.18  -1.400, "Talk", 7, 0.1, 0.1)
			Draw3DText( 418.02, -1921.48, 25.18  -1.600, "To", 7, 0.1, 0.1)	
		end
	end
end
---------------------------------------CONTROLLER TAIL-------------------------------------------------------------------
---------------------------------------DO NOT EDIT-----------------------------------------------------------------------
function Draw3DText(x,y,z,textInput,fontId,scaleX,scaleY)
         local px,py,pz=table.unpack(GetGameplayCamCoords())
         local dist = GetDistanceBetweenCoords(px,py,pz, x,y,z, 1)    
         local scale = (1/dist)*20
         local fov = (1/GetGameplayCamFov())*100
         local scale = scale*fov   
         SetTextScale(scaleX*scale, scaleY*scale)
         SetTextFont(fontId)
         SetTextProportional(1)
         SetTextColour(250, 250, 250, 255)		-- You can change the text color here
         SetTextDropshadow(1, 1, 1, 1, 255)
         SetTextEdge(2, 0, 0, 0, 150)
         SetTextDropShadow()
         SetTextOutline()
         SetTextEntry("STRING")
         SetTextCentre(1)
         AddTextComponentString(textInput)
         SetDrawOrigin(x,y,z+2, 0)
         DrawText(0.0, 0.0)
         ClearDrawOrigin()
        end
---------------------------------------CONTROLLER TAIL-------------------------------------------------------------------
---------------------------------------DO NOT EDIT-----------------------------------------------------------------------
local blips = {
----------------------------------------HOLO TEXT CONFIG-----------------------------------------------------------------
------------------------------EDIT HERE ONLY -- SEE EXAMPLE BELOW-------------------------------------------------------

	{title="BLIP NAME", colour=24, id=197, x = 000.000, y = -000.000, z = 00.00}, -- EXAMPLE (Replace Blip Name, Colour, Id, X, Y, Z)
	{title="BLIP NAME", colour=24, id=197, x = 000.000, y = -000.000, z = 00.00}, -- EXAMPLE (Replace Blip Name, Colour, Id, X, Y, Z)
	{title="BLIP NAME", colour=24, id=197, x = 000.000, y = -000.000, z = 00.00}, -- EXAMPLE (Replace Blip Name, Colour, Id, X, Y, Z)
	{title="BLIP NAME", colour=24, id=197, x = 000.000, y = -000.000, z = 00.00}, -- EXAMPLE (Replace Blip Name, Colour, Id, X, Y, Z)
   -- {title="BLIP NAME", colour=29 , id=459, x = -658.07, y =  -857.52, z = 24.49}, -- Adding (--) before the blip will cancel that blip but keep your coordinates in one location

  }
--------------------------------------CONTROLER STARTS-------------------------------------------------------------------
---------------------------------------DO NOT EDIT-----------------------------------------------------------------------	   
  Citizen.CreateThread(function()
  
	 for _, info in pairs(blips) do
	   info.blip = AddBlipForCoord(info.x, info.y, info.z)
	   SetBlipSprite(info.blip, info.id)
	   SetBlipDisplay(info.blip, 4)
	   SetBlipScale(info.blip, 0.8)
	   SetBlipColour(info.blip, info.colour)
	   SetBlipAsShortRange(info.blip, true)
	   BeginTextCommandSetBlipName("STRING")
	   AddTextComponentString(info.title)
	   EndTextCommandSetBlipName(info.blip)
	 end
  end)
---------------------------------------CONTROLLER ENDS-------------------------------------------------------------------
---------------------------------------DO NOT EDIT-----------------------------------------------------------------------

  
 





